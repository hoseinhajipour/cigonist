@section('title', 'Home')

<div class="d-grid col-lg-4 mx-auto">
    <div class="card">
        <div class="card-header">
            @yield('title')
        </div>
        <div class="card-body">
            You are logged in!
        </div>
    </div>
</div>
