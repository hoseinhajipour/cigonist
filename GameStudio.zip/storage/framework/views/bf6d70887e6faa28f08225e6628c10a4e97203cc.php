<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>

    <?php echo \Livewire\Livewire::styles(); ?>


    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/dist/css/bootstrap.min.css')); ?> " type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/font-awesome/css/all.min.css')); ?> " type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/themify-icons/css/themify-icons.css')); ?> " type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/slick/slick.min.css')); ?> " type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/featherlight/featherlight.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/featherlight/featherlight.gallery.min.css')); ?>"
          type="text/css">

    <!-- Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Open+Sans:wght@300;400;600;700&display=swap"
        rel="stylesheet">

    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/utilities.css')); ?>">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
</head>
<body data-spy="scroll" data-target="#navbarCollapse" class="bg-gray-800">
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('inc.menu', [])->html();
} elseif ($_instance->childHasBeenRendered('krxILTx')) {
    $componentId = $_instance->getRenderedChildComponentId('krxILTx');
    $componentTag = $_instance->getRenderedChildComponentTagName('krxILTx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('krxILTx');
} else {
    $response = \Livewire\Livewire::mount('inc.menu', []);
    $html = $response->html();
    $_instance->logRenderedChild('krxILTx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<main>
    <?php echo e($slot); ?>

</main>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo \Livewire\Livewire::scripts(); ?>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<!-- Libs JS -->

<script src="<?php echo e(asset('assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/popper.js/dist/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-validation/dist/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-form/dist/jquery.form.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/imagesloaded/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/isotope/dist/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/featherlight/featherlight.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/featherlight/jquery.detect_swipe.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/featherlight/featherlight.gallery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery.scrollTo/jquery.scrollTo.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jQuery.countdown/dist/jquery.countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/typed.js/typed.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/slick/slick.min.js')); ?>"></script>

<!-- Theme JS -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\2024\GameStudio\GameStudio\resources\views/layouts/app.blade.php ENDPATH**/ ?>