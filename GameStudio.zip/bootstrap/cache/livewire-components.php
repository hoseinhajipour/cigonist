<?php return array (
  'auth.login' => 'App\\Components\\Auth\\Login',
  'auth.logout' => 'App\\Components\\Auth\\Logout',
  'auth.password-forgot' => 'App\\Components\\Auth\\PasswordForgot',
  'auth.password-reset' => 'App\\Components\\Auth\\PasswordReset',
  'auth.register' => 'App\\Components\\Auth\\Register',
  'home' => 'App\\Components\\Home',
  'inc.menu' => 'App\\Components\\Inc\\Menu',
  'index' => 'App\\Components\\Index',
);