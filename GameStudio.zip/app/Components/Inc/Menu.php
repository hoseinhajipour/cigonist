<?php

namespace App\Components\Inc;

use Livewire\Component;

class Menu extends Component
{
    public function render()
    {
        return view('inc.menu');
    }
}
